/*
 * defines.h
 *
 *  Created on: Apr 8, 2016
 *      Author: erowland
 */

#ifndef DEFINES_H_
#define DEFINES_H_

//#define OFF 0
#define BLUE 1
#define MAIZE 2
#define START 3
#define TIEGAME 4
#define EGG1 5
#define EGG2 6
#define EGG3 7
#define INTERRUPT 9

#define NUM_GPIO_PINS 8

#define MAX_EGGIE_LENGTH 11
#define NUM_EASTER_EGGS 3
#define MAX_WAITING_EGGIES 10

#define COUNT_START 5

#define FULL_BUFFER_SIZE 16
#define DIGITAL_BUFFER_SIZE 18

#define TIMER_LENGTH 25 // in milliseconds

#define NUM_BYTES_SENT 4

#define NUM_CARS 4

#define SCOREMAX 10
#define GAMELENGTH 300 // In seconds, 5min * 60secs/min = 300 secs

#endif /* DEFINES_H_ */
