/**************************************\
 * File Name:      eggie.c
 * Project Name:   EECS 373 Final Project
 * Created by:     Emily Rowland
 * Start date:     16 April 2016
\**************************************/

#include "eggie.h"
#include "arena.h"
#include <stdio.h>

// Global controller structs
extern controller_t controller1;
extern controller_t controller2;
extern controller_t controller3;
extern controller_t controller4;

extern void stopCars();
extern void send_data_to_car(controller_t *);
extern void teamScored(int);

/********** EGGIE VARIABLES **********/

uint16_t eggies[NUM_EASTER_EGGS][MAX_EGGIE_LENGTH];
egg_waiter_t waiting_eggs[MAX_WAITING_EGGIES];
uint8_t num_eggs_waiting;
uint8_t GPIO_eggie[NUM_EASTER_EGGS];
uint8_t eggie_limit[NUM_CARS][NUM_EASTER_EGGS];

// All setup needed for easter eggs
void init_easter_eggs() {

	num_eggs_waiting = 0;

	int i;
	for (i = 0; i < MAX_WAITING_EGGIES; ++i) {
		waiting_eggs[i].controller = 0;
		waiting_eggs[i].light_show = 0;
	}

	// Setup GPIO pins
	GPIO_eggie[0] = 5;
	GPIO_eggie[1] = 6;
	GPIO_eggie[2] = 7;

	// Limit on number of easter eggs per player
	for (i = 0; i < NUM_CARS; ++i) {
		eggie_limit[i][0] = 5;
		eggie_limit[i][1] = 1;
		eggie_limit[i][2] = 1;
	}

	// Setup up easter egg sequences
	// NOTE: Every other state in the sequence must be a zero state
	// Last state will be zero to indicate we are finished

	// First show: Triangle -> Circle -> X -> Square -> Triangle
	eggies[0][0] = 0xffff;
	eggies[0][1] = 0xfff7; // triangle
	eggies[0][2] = 0xffff;
	eggies[0][3] = 0xfffb; // circle
	eggies[0][4] = 0xffff;
	eggies[0][5] = 0xfffd; // X
	eggies[0][6] = 0xffff;
	eggies[0][7] = 0xfffe; // square
	eggies[0][8] = 0xffff;
	eggies[0][9] = 0xfff7; // triangle
	eggies[0][10] = 0;

	// Second show: Right -> Down -> Left -> Up -> Right
	eggies[1][0] = 0xffff;
	eggies[1][1] = 0xfbff; // right
	eggies[1][2] = 0xffff;
	eggies[1][3] = 0xfdff; // down
	eggies[1][4] = 0xffff;
	eggies[1][5] = 0xfeff; // left
	eggies[1][6] = 0xffff;
	eggies[1][7] = 0xf7ff; // up
	eggies[1][8] = 0xffff;
	eggies[1][9] = 0xfbff; // right
	eggies[1][10] = 0;

	// Third show: R1 -> R2 -> L2 -> L1
	eggies[2][0] = 0xffff;
	eggies[2][1] = 0xffef; // r1
	eggies[2][2] = 0xffff;
	eggies[2][3] = 0xffbf; // r2
	eggies[2][4] = 0xffff;
	eggies[2][5] = 0xff7f; // l2
	eggies[2][6] = 0xffff;
	eggies[2][7] = 0xffdf; // l1
	eggies[2][8] = 0;
}


// Check each easter egg sequence with this controller
void check_easter_eggs(controller_t * controller) {

	// Get digital values of buttons
	uint16_t buttons = (controller->digi[0] << 8) | controller->digi[1];
	//printf("Buttons: %x\r\n", (int) buttons);

	// Compare to last buffer
	if ((buttons | (~0x9fff)) == (controller->last_buttons | (~0x9fff))) {
		controller->last_buttons = buttons;
		return; // no change in button status
	}

	// Check if next state
	int egg;
	for (egg = 0; egg < NUM_EASTER_EGGS; ++egg) {

		// Check for state 2 corner case error
		if ( 	(controller->state[egg] == 2) &&
				(((uint16_t) (buttons | ~0x9fff)) == eggies[egg][1]) ) {

			printf("Corner Case\r\n");
			return;
		}

		// If the current buttons are the same as the ones for the next state
		if ( ((uint16_t) (buttons | ~0x9fff)) == eggies[egg][controller->state[egg] + 1]) {

			// Move to the next state
			++(controller->state[egg]);

			printf("State to %d for egg %d\r\n", controller->state[egg], egg);

			// Check if this is the end state
			if ((num_eggs_waiting < NUM_EASTER_EGGS) &&
				(eggies[egg][controller->state[egg] + 1] == 0) &&
				(eggie_limit[controller->select-1][egg] != 0) ) {

				// Add the easter egg
				printf("Egg Light show added to queue!!!\r\n");
				waiting_eggs[num_eggs_waiting].controller = controller->select;
				waiting_eggs[num_eggs_waiting].light_show = egg;
				++num_eggs_waiting;

				controller->state[egg] = 0; // Reset the state
			}
		}

		// If not next state, return to first state
		else {
			controller->state[egg] = 0; // Reset the state
		}
	}

	printf("state: %d\r\n", controller->state[0]);
	controller->last_buttons = buttons;
}



// Run easter egg codes if there are some waiting
void run_eggies() {

	NVIC_DisableIRQ(Fabric_IRQn); 	// Disable the timer interrupts

	// Check for waiting eggs
	if (num_eggs_waiting > 0 && ((MSS_GPIO_get_inputs() & MSS_GPIO_8_MASK) == MSS_GPIO_8_MASK)) {

		// Remove the waiting eggie from the list
		uint8_t car_id = waiting_eggs[0].controller;
		uint8_t show = waiting_eggs[0].light_show;
		--num_eggs_waiting;

		printf("Num eggs waiting: %d\r\n", (int) num_eggs_waiting);

		// Shift other waiting eggies down
		int i;
		for(i = 0; i < num_eggs_waiting; ++i){
			waiting_eggs[i] = waiting_eggs[i+1];
		}

		if (eggie_limit[car_id-1][show] > 0) {
			eggie_limit[car_id-1][show] -= 1;
		}

		printf("Remaining for car %d: %d\r\n", car_id-1, eggie_limit[car_id-1][show]);

		// ENTER THE SPECIAL BONUS MODE

		// Find which controllers to control
		controller_t * first_car = NULL;
		controller_t * second_car = NULL;

		// Run the light show
		printf("Eggie show starting now\r\n");
		ARENA_outputEggActivated();
		light_show(GPIO_eggie[show]);
		wait_lights_start();
		turn_off_lights();
		stopCars();


		switch (car_id) {
		case 1:
			first_car = &controller1;
			second_car = &controller3;
			break;
		case 2:
			first_car = &controller2;
			second_car = &controller4;
			break;
		case 3:
			first_car = &controller1;
			second_car = &controller3;
			break;
		case 4:
			first_car = &controller2;
			second_car = &controller4;
			break;
		}

		// Continue while the show is still going
		while ((MSS_GPIO_get_inputs() & MSS_GPIO_8_MASK) == 0) {

			poll_delay(1);
			send_data_to_car(first_car);
			poll_delay(1);
			send_data_to_car(second_car);

			// Debugging
			if (controller1.data[5] > 100 && controller1.data[11] > 100) {
				teamScored(MAIZE);
			}
			if (controller1.data[4] > 100 && controller1.data[9] > 100) {
				teamScored(BLUE);
			}
		}
	}

	NVIC_EnableIRQ(Fabric_IRQn); 	// Disable the timer interrupts
}


// Clear all waiting eggs
void clear_waiting_eggs() {
	num_eggs_waiting = 0;
}


