/**************************************\
 * File Name:      eggie.h
 * Project Name:   EECS 373 Final Project
 * Created by:     Emily Rowland
 * Start date:     16 April 2016
\**************************************/

#ifndef EGGIE_H_
#define EGGIE_H_

#include "ps2.h"
#include "light_show.h"
#include "defines.h"
#include "linked_list.h"

typedef struct egg_waiter {
	uint8_t controller;
	uint8_t light_show;
} egg_waiter_t;


// Initialize the easter egg code (run only once)
void init_easter_eggs();

// Check each easter egg sequence with this controller
void check_easter_eggs(controller_t * controller);

// Run easter egg codes if there are some waiting
void run_eggies();

#endif /* EGGIE_H_ */
