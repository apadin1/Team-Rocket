/**************************************\
 * File Name:      ps2.c
 * Project Name:   EECS 373 Final Project
 * Created by:     Adrian Padin
 * Start date:     22 March 2016
\**************************************/

#include "ps2.h"
#include "light_show.h"
#include "defines.h"
#include <stdio.h>


// Global controller structs
controller_t controller1;
controller_t controller2;
controller_t controller3;
controller_t controller4;

// Initialize the controller struct
void controller_init(controller_t * controller, uint8_t select) {

	// Configure SPI select
	MSS_SPI_configure_master_mode
	(
		&g_mss_spi1,
		select,
		MSS_SPI_MODE3,		  // Clock idle high, read on rising edge
		MSS_SPI_PCLK_DIV_256, // Clock period of 20MHz / 256 ~= 78 KHz
		MSS_SPI_BLOCK_TRANSFER_FRAME_SIZE
	);

	// Initialize all values
	controller->select = select;
	controller->vibration = 0;
	controller->counter = 0;
	controller->last_buttons = 0xff;

	// Reset all easter egg states
	int i;
	for(i = 0; i < NUM_EASTER_EGGS; i++){
		controller->state[i] = 0;
	}

	// Clear data buffers
	for (i = 0; i < FULL_BUFFER_SIZE; ++i) {
		controller->data[i] = 0;
	}

	for (i = 0; i < DIGITAL_BUFFER_SIZE; ++i) {
		controller->digi[i] = 0;
	}
}

/********** HELPER FUNCTIONS **********/

// Flip the bits of an 8-bit value
uint8_t flip(uint8_t value) {

	uint8_t buffer = 0;
	buffer |= (value & 0x80) >> 7;
	buffer |= (value & 0x40) >> 5;
	buffer |= (value & 0x20) >> 3;
	buffer |= (value & 0x10) >> 1;
	buffer |= (value & 0x08) << 1;
	buffer |= (value & 0x04) << 3;
	buffer |= (value & 0x02) << 5;
	buffer |= (value & 0x01) << 7;
	return buffer;
}



/********** COMMAND FUNCTIONS **********/

// Poll for just digital values
// static void digital_poll(uint8_t * data);

// Poll for all values
// static void full_poll(uint8_t * data);

// Enter configuration mode
static void enter_config(uint8_t * data);

// Exit configuration mode
static void exit_config(uint8_t * data);

// Turn on analog mode
static void enable_analog(uint8_t * data);

// Map motors to correct bytes
static void motor_setup(uint8_t * data);

// Setup analog buttons
static void button_setup(uint8_t * data);



// Poll for digital button values
void digital_capture(controller_t * controller) {

	// Select controller
	MSS_SPI_set_slave_select( &g_mss_spi1, controller->select );

	uint8_t master_buffer[5]  = { 0x80, flip(0x42), 0x00, 0x00, 0x00 };
	MSS_SPI_transfer_block
	(
	    &g_mss_spi1,
	    (uint8_t *) master_buffer, 3,
	    (uint8_t *) controller->digi, DIGITAL_BUFFER_SIZE
	);

	// Deselect controller
	MSS_SPI_clear_slave_select( &g_mss_spi1, controller->select );
}


// Poll for all values
void full_capture(controller_t * controller) {
	// Only vibrate for a certain amount of time
	int vibration = 0;
	if (controller->counter > 0) {
		controller->counter -= 1;
		vibration = controller->vibration;
	}

	//if (controller->vibration > 0) {
	//	vibration = 0xff;
	//}

	// Select controller
	MSS_SPI_set_slave_select( &g_mss_spi1, controller->select );

	uint8_t master_buffer[5]  = { 0x80, flip(0x42), 0x00, vibration, vibration };
	MSS_SPI_transfer_block
	(
	    &g_mss_spi1,
	    (uint8_t *) master_buffer, 5,
	    (uint8_t *) controller->data, FULL_BUFFER_SIZE
	);

	// Select controller
	MSS_SPI_clear_slave_select( &g_mss_spi1, controller->select );

	// If right and left buttons are at 255, don't send this nessage (shouldn't be possible)
	int i;
	if(controller->data[4] == 0xFF && controller->data[5] == 0xFF) {
		controller->data[0] = 128;
		controller->data[1] = 128;
		controller->data[2] = 128;
		controller->data[3] = 128;
		for (i = 4; i < FULL_BUFFER_SIZE; ++i) {
			controller->data[i] = 0;
		}
	}
}

// Perform all setup tasks on this controller
void setup_all(controller_t * controller) {

	// Poll once for fun
	digital_capture(controller);

	// Select controller
	MSS_SPI_set_slave_select( &g_mss_spi1, controller->select );
	uint8_t * data = (uint8_t *) (controller->data);

	// Delays are added to ensure signals are not confused
	int i = 0;

	enter_config(data);		// Enter configuration mode
	for (i = 0; i < 200; ++i); 		// Delay
	enable_analog(data);	// Enable analog mode on the controller
	for (i = 0; i < 200; ++i); 		// Delay
	motor_setup(data);		// Setup the motor to map to the proper bytes
	for (i = 0; i < 200; ++i); 		// Delay
	button_setup(data);		// Configure the buttons to send analog data
	for (i = 0; i < 200; ++i); 		// Delay
	exit_config(data);		// Exit configuration mode
}

// Set the controller to vibrate for a predetermined amount of time
void set_vibration(controller_t * controller, uint8_t vibration) {

	controller->vibration = vibration;
	controller->counter = COUNT_START;
}

// Enter configuration mode
void enter_config(uint8_t * data) {

	uint8_t master_buffer[5]  = { 0x80, flip(0x43), 0x00, 0x80, 0x00 };
	MSS_SPI_transfer_block
	(
	    &g_mss_spi1,
	    (uint8_t *) master_buffer, 5,
	    (uint8_t *) data, 0
	);
}

// Exit configuration mode
void exit_config(uint8_t * data) {

	uint8_t master_buffer[9] = { 0x80, flip(0x43), 0x00, 0x00, 0x5A, 0x5A, 0x5A, 0x5A, 0x5A };
	MSS_SPI_transfer_block
	(
	    &g_mss_spi1,
	    (uint8_t *) master_buffer, 9,
	    (uint8_t *) data, 0
	);
}

// Turn on analog mode
void enable_analog(uint8_t * data) {

	uint8_t master_buffer[9] = { 0x80, flip(0x44), 0x00, 0x80, 0xC0, 0xFF, 0xFF, 0xFF, 0xFF };
	MSS_SPI_transfer_block
	(
	    &g_mss_spi1,
	    (uint8_t *) master_buffer, 9,
	    (uint8_t *) data, 0
	);
}

// Map motors to correct bytes
void motor_setup(uint8_t * data) {

	uint8_t master_buffer[9] = { 0x80, flip(0x4D), 0x00, 0x00, 0x80, 0xFF, 0xFF, 0xFF, 0xFF };
	MSS_SPI_transfer_block
	(
	    &g_mss_spi1,
	    (uint8_t *) master_buffer, 9,
	    (uint8_t *) data, 0
	);
}

// Setup analog buttons
void button_setup(uint8_t * data) {

	uint8_t master_buffer[9] = { 0x80, flip(0x4F), 0x00, 0xFF, 0xFF, 0xC0, 0x00, 0x00, 0x00 };
	MSS_SPI_transfer_block
	(
	    &g_mss_spi1,
	    (uint8_t *) master_buffer, 9,
	    (uint8_t *) data, 0
	);
}

// check if other buttons besides desired are pressed
uint8_t other_pressed(uint8_t * data, uint8_t index){
	uint8_t pressed=0;
	printf("index: %d\n\r", index);
	int i;
	for(i=4; i < FULL_BUFFER_SIZE; i++){
		if((data[i]>0) && (i!=index)) pressed=1;
	}
	return pressed;
}

// Delay a certain number of cycles while keeping the controllers alive
void poll_delay(int cycles) {

	// Add to the cycles so as not to affect vibration while delaying
	controller1.counter += cycles;
	controller2.counter += cycles;
	controller3.counter += cycles;
	controller4.counter += cycles;

	// Full capture is important; digital capture may have
	// unexpected behavior in relation to vibration
	int i;
	for (i = 0; i < cycles; i++) {
		full_capture(&controller1);
		full_capture(&controller2);
		full_capture(&controller3);
		full_capture(&controller4);
	}
}

// Doesn't return until all 4 controllers press and hold X at the same time
void buttonWait() {

	printf("Before waiting for controllers\n\r");

	// Wait for all controllers to press and hold X
	while ( flip(controller1.data[10]) < 10
			|| flip(controller2.data[10]) < 10
			|| flip(controller3.data[10]) < 10
			|| flip(controller4.data[10]) < 10
			) {

		poll_delay(1); // poll controllers
	}

	printf("After waiting for controllers\n\r");
}
